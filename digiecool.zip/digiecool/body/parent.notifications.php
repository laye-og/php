<div class="dropdown-menu dropdown-menu-right mailbox animated zoomIn">
    <ul>
        <li>
            <div class="drop-title">Notifications</div>
        </li>
        <li>
            <div class="message-center">
                <!-- Message -->
                <a href="#">
                    <div class="btn btn-danger btn-circle m-r-10"><i class="fa fa-link"></i></div>
                    <div class="mail-contnet">
                        <h5>This is title</h5> <span class="mail-desc">Just see the my new admin!</span> <span class="time">9:30 AM</span>
                    </div>
                </a>
                <!-- Message -->
                <a href="#">
                    <div class="btn btn-success btn-circle m-r-10"><i class="ti-calendar"></i></div>
                    <div class="mail-contnet">
                        <h5>This is another title</h5> <span class="mail-desc">Just a reminder that you have event</span> <span class="time">9:10 AM</span>
                    </div>
                </a>
                <!-- Message -->
                <a href="#">
                    <div class="btn btn-info btn-circle m-r-10"><i class="ti-settings"></i></div>
                    <div class="mail-contnet">
                        <h5>This is title</h5> <span class="mail-desc">You can customize this template as you want</span> <span class="time">9:08 AM</span>
                    </div>
                </a>
                <!-- Message -->
                <a href="#">
                    <div class="btn btn-primary btn-circle m-r-10"><i class="ti-user"></i></div>
                    <div class="mail-contnet">
                        <h5>This is another title</h5> <span class="mail-desc">Just see the my admin!</span> <span class="time">9:02 AM</span>
                    </div>
                </a>
            </div>
        </li>
        <li>
            <a class="nav-link text-center" href="javascript:void(0);"> <strong>Check all notifications</strong> <i class="fa fa-angle-right"></i> </a>
        </li>
    </ul>
</div>
