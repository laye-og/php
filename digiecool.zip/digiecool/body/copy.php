<!-- footer -->
<footer class="foote"> © 2018 All rights reserved. ALIN-TECH</footer>

<!-- End footer -->
