<?php
require_once("_config/config.php");
require_once("body/header.php");
require_once("body/".PREFIXE1."menu.php");
require_once("pages/inscription.php");
require_once("body/footer.php"); ?>
