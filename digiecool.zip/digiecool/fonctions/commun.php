<?php
function secure($val){
    return htmlspecialchars(trim($val));
}

?>
