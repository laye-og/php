<?php 
    if (isset($_GET['type_compte'])) {
    $type_compte=$_GET['type_compte'];
   }
   else {die("acces non autorisé");}
  
 ?>
    <!-- Bread crumb -->
    <div class="row page-titles">
        <div class="col-md-5 align-self-center">
            <h3 class="text-primary">Bonjour  </h3> </div>
        <div class="col-md-7 align-self-center" >
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item active"><?php echo $type_compte; ?></li>
            </ol>
        </div>
    </div>
    <!-- End Bread crumb -->
    <!-- Container fluid  -->
    <div style="height:50px;"></div>
    <center><h1>Administration des comptes <?php echo $type_compte; ?> </h1> </center> 
    <div style="height:100px;"></div>
     <div style="width: 100%; height: 30%; "></div>
    <div class="container-fluid">
        <!-- Start Page Content -->
        <div class="row">

             <div style="width: 50px;"></div>
            <div class="col-md-3">
                <div class="card p-30">
                    <div class="media">
                        <div class="media-left meida media-middle">
                        </div>
                        <div class="media-body media-text-right" >
                            <center>
                        <p class="m-b-0">Ajouter <?php echo $type_compte; ?></p><hr>
                  <? echo"<a href=gestion_compte.insc.php?type_compte=$type_compte>"?><img src="images/addcouleur.png"></a>
                        </center>
                        <br>
                        </div>
                    </div>
                </div>
            </div>
            <div class="space2"></div>
            <div class="col-md-3">
                <div class="card p-30">
                    <div class="media">
                        <div class="media-left meida media-middle"></div>
                        <div class="media-body media-text-right">
                            <center>
                         <p class="m-b-0">Supprimer <?php echo $type_compte; ?></p><hr>
                        <? echo"<a href=gestion_compte.supp.php?type_compte=$type_compte>"?>  <img src="images/delete.png">
                         </center>
                         <br>
                     </div>
                    </div>
                </div>
            </div>
            <div class="space2"></div>
            <div class="col-md-3">
                <div class="card p-30">
                    <div class="media">
                        <div class="media-left meida media-middle"> </div>
                        <div class="media-body media-text-right">
                            <center>
                            <p class="m-b-0">Modifier compte <?php echo $type_compte; ?><hr>
                             <? echo"<a href=gestion_compte.supp.php?type_compte=$type_compte>"?>    <img src="images/modif.png">
                                 </center>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
    </div>
    <!-- End Container fluid  -->
