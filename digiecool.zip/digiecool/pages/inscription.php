<<?php 
   if (isset($_GET['type_compte'])) {
    $type_compte=$_GET['type_compte'];
   }
   else {die("acces non autorisé");}
  
 ?> <!-- Bread crumb -->
    <div class="row page-titles">
        <div class="col-md-5 align-self-center">
            <h3 class="text-primary">Bonjour  </h3> </div>
        <div class="col-md-7 align-self-center">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item active"><?php echo $type_compte; ?></li>
            </ol>
        </div>
    </div>
    <!-- End Bread crumb -->
    <!-- Container fluid  -->
   <div class="row">
    <div style="width: 300px;"></div>
                    <div class="col-lg-6">
                        <div class="card card-outline-primary">
                            <div class="card-header">
                               <center> <h4 class="m-b-0 text-white">Creer un compte <?php echo $type_compte; ?> </h4></center>
                            </div>
                            <div class="card-body"> 
                                <form action="#">
                                    <div class="form-body">
                                      <center>  <h3 class="card-title m-t-15"> Info de la personne</h3></center>
                                        <hr>
                                        <div class="row p-t-20">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Prénom</label>
                                                    <input type="text" id="firstName" class="form-control" placeholder="John doe">
                                                      </div>
                                            </div>
                                            <!--/span-->
                                            <div class="col-md-6">
                                                <div class="form-group has-danger">
                                                    <label class="control-label">Nom</label>
                                                    <input type="text" id="lastName" class="form-control form-control-danger" placeholder="12n">
                                                    </div>
                                            </div>
                                            <!--/span-->
                                        </div>
                                        <!--/row-->
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group has-success">
                                                    <label class="control-label">Genre</label>
                                                    <select class="form-control custom-select">
                                                        <option value="">Homme</option>
                                                        <option value="">Femme</option>
                                                    </select>
                                                    <small class="form-control-feedback"> Selectionné le genre  </small> </div>
                                            </div>
                                            <!--/span-->
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">Date de naissance</label>
                                                    <input type="date" class="form-control" placeholder="dd/mm/yyyy">
                                                </div>
                                            </div>
                                            <!--/span-->
                                        </div>

                                       <center> <h3 class="box-title m-t-40">Addresse</h3></center>
                                        <hr>
                                       
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Ville</label>
                                                    <input type="text" class="form-control">
                                                </div>
                                            </div>
                                            <!--/span-->
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Region </label>
                                                    <input type="text" class="form-control">
                                                </div>
                                            </div>
                                            <!--/span-->
                                        </div>
                                        <!--/row-->
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Numéro de téléphone </label>
                                                    <input type="text" class="form-control">
                                                </div>
                                            </div>
                                           
                                        </div>
                                    </div>
                                    <div class="form-actions">
                                        <button type="submit" class="btn btn-success"> <i class="fa fa-check"></i>Valider</button>
                                        <button type="button" class="btn btn-inverse">Arreter</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
