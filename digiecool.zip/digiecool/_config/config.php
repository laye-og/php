<?php
    define("PATH_BODY","body/");
    define("PATH_PAGES","pages/");
    define("PREFIXE","parent.");
    define("PREFIXE1","compte.");
    define("DEFAULT_PAGE_PARENT","accueil");
    require_once("_config/".PREFIXE."loader.php");
?>
