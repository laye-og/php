<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		

	.banere{
		height: 100px;
		width: 100%;
		background-color: #0A2A0A; 
	}
	</style>
</head>
<body>
	<div class="banere">
	<center>
<img src="baniere/wimbledonLogo.png">
</center>
</div>
</body>
</html>